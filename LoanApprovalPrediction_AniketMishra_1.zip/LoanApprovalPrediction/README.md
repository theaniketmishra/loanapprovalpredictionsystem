# Loan Approval Prediction System

**AIML Summer Internship 2026 — IIHMF, MNNIT Allahabad, Prayagraj**
**Capstone Project 3** | Team Leader: Aniket Mishra

## Objective
Develop a predictive system to determine whether a loan application should be approved,
based on applicant demographic, financial, and credit information.

## Project Structure
```
LoanApprovalPrediction/
│
├── Dataset/
│   ├── loan_data.csv          # dataset (Kaggle Loan Prediction schema)
│   └── generate_dataset.py    # script used to generate the dataset
├── Notebook/
│   └── Loan_Approval_Prediction.ipynb   # full EDA + modeling, pre-executed with outputs
├── Model/                     # saved model artifacts for deployment
│   ├── best_model.pkl
│   ├── scaler.pkl
│   ├── encoders.pkl
│   ├── target_encoder.pkl
│   ├── feature_list.json
│   └── results.json
├── Streamlit_App/
│   └── app.py                 # deployment web app
├── Documentation/             # for report/PPT/screenshots
├── requirements.txt
└── README.md
```

## Machine Learning Lifecycle
1. **Problem Understanding** — predict `Loan_Status` (Approved/Rejected)
2. **Data Collection** — Kaggle-style Loan Prediction dataset schema (614 records, 13 columns)
3. **Data Preprocessing** — missing value imputation (mode/median), duplicate check, IQR-based outlier capping, label encoding
4. **EDA** — univariate, bivariate, and correlation analysis with histograms, boxplots, scatter plots, heatmaps
5. **Feature Engineering** — `TotalIncome`, log transforms, `EMI`, `Balance_Income`; categorical label encoding
6. **Model Building** — Logistic Regression, Random Forest, XGBoost, trained on SMOTE-balanced data
7. **Model Evaluation** — Accuracy, Precision, Recall, F1-Score, ROC-AUC, Confusion Matrix, ROC curves
8. **Model Deployment** — Streamlit web app for real-time prediction

## Results Summary (Test Set)
| Model | Accuracy | Precision | Recall | F1-Score | ROC-AUC |
|---|---|---|---|---|---|
| **XGBoost (Best)** | 0.821 | 0.818 | 0.844 | 0.831 | 0.899 |
| Random Forest | 0.780 | 0.794 | 0.781 | 0.787 | 0.883 |
| Logistic Regression | 0.772 | 0.781 | 0.781 | 0.781 | 0.881 |

**Best Model:** XGBoost, selected by F1-Score, saved to `Model/best_model.pkl`.
(Exact numbers will vary slightly each time the notebook is re-run / data regenerated.)

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Regenerate the dataset (optional — one is already included)
```bash
cd Dataset
python generate_dataset.py
```

### 3. Run the notebook
Open `Notebook/Loan_Approval_Prediction.ipynb` in Jupyter to re-run the full
analysis, train the models, and re-save artifacts to `Model/`.

### 4. Launch the Streamlit app
```bash
cd Streamlit_App
streamlit run app.py
```
The app loads the saved model artifacts and provides an interactive form to
enter applicant details and get an instant Approved/Rejected prediction with
a confidence score.

## Note on Dataset
A synthetic dataset matching the exact schema and statistical characteristics
of the well-known Kaggle "Loan Prediction" dataset was generated for this
project (`Dataset/loan_data.csv`), including realistic missing values and
class imbalance. You may substitute the actual Kaggle dataset (same column
names) without changing any code — just replace the CSV file.

## Academic Integrity
This project was built as a learning scaffold. Per the program's academic
integrity policy, students must understand and be able to explain every line
of code before submission, and should adapt/extend the analysis (e.g., try
different features, tune hyperparameters, add their own commentary) rather
than submitting it unmodified.
