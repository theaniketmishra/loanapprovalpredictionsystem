"""
Generates a synthetic dataset that mirrors the schema and statistical
patterns of the well-known Kaggle "Loan Prediction" dataset
(columns: Loan_ID, Gender, Married, Dependents, Education, Self_Employed,
ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term,
Credit_History, Property_Area, Loan_Status).

Run this once to create loan_data.csv inside the Dataset folder.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
N = 614  # same size as the original Kaggle dataset

gender = np.random.choice(["Male", "Female"], N, p=[0.81, 0.19])
married = np.random.choice(["Yes", "No"], N, p=[0.65, 0.35])
dependents = np.random.choice(["0", "1", "2", "3+"], N, p=[0.58, 0.17, 0.17, 0.08])
education = np.random.choice(["Graduate", "Not Graduate"], N, p=[0.78, 0.22])
self_employed = np.random.choice(["Yes", "No"], N, p=[0.14, 0.86])
property_area = np.random.choice(["Urban", "Semiurban", "Rural"], N, p=[0.38, 0.38, 0.24])
credit_history = np.random.choice([1.0, 0.0], N, p=[0.84, 0.16])
loan_amount_term = np.random.choice([360, 180, 120, 60, 300, 240, 84, 12, 36], N,
                                     p=[0.71, 0.07, 0.06, 0.03, 0.03, 0.04, 0.02, 0.02, 0.02])

applicant_income = np.random.lognormal(mean=8.55, sigma=0.55, size=N).astype(int)
coapplicant_income = np.where(
    married == "Yes",
    np.random.lognormal(mean=7.7, sigma=0.9, size=N).astype(int),
    0
)
coapplicant_income = np.where(np.random.rand(N) < 0.25, 0, coapplicant_income)

base_loan = (applicant_income + coapplicant_income) / np.random.uniform(6, 9, N)
loan_amount = np.round(base_loan / 10).astype(int) * 10
loan_amount = np.clip(loan_amount, 9, 700)

# Inject some missing values, similar to the real dataset
def inject_missing(arr, frac):
    arr = arr.astype(object)
    idx = np.random.choice(len(arr), int(len(arr) * frac), replace=False)
    arr[idx] = None
    return arr

gender = inject_missing(gender, 0.02)
married = inject_missing(married, 0.005)
dependents = inject_missing(dependents, 0.025)
self_employed = inject_missing(self_employed, 0.05)
loan_amount_f = inject_missing(loan_amount.astype(float), 0.035)
loan_amount_term_f = inject_missing(loan_amount_term.astype(float), 0.022)
credit_history_f = inject_missing(credit_history.astype(float), 0.08)

# Approval probability driven by realistic factors
score = (
    2.6 * (credit_history == 1.0).astype(float)
    + 0.0009 * (applicant_income + coapplicant_income)
    - 0.012 * loan_amount
    + 0.5 * (education == "Graduate").astype(float)
    + 0.3 * (property_area == "Semiurban").astype(float)
    - 0.4 * (property_area == "Rural").astype(float)
    + np.random.normal(0, 1.0, N)
)
prob = 1 / (1 + np.exp(-(score - 1.0)))
loan_status = np.where(prob > 0.5, "Y", "N")

loan_id = [f"LP{str(i).zfill(6)}" for i in range(1, N + 1)]

df = pd.DataFrame({
    "Loan_ID": loan_id,
    "Gender": gender,
    "Married": married,
    "Dependents": dependents,
    "Education": education,
    "Self_Employed": self_employed,
    "ApplicantIncome": applicant_income,
    "CoapplicantIncome": coapplicant_income,
    "LoanAmount": loan_amount_f,
    "Loan_Amount_Term": loan_amount_term_f,
    "Credit_History": credit_history_f,
    "Property_Area": property_area,
    "Loan_Status": loan_status,
})

df.to_csv("/home/claude/LoanApprovalPrediction/Dataset/loan_data.csv", index=False)
print("Saved loan_data.csv with shape:", df.shape)
print(df["Loan_Status"].value_counts())
