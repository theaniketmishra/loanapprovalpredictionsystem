import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

md("""# Loan Approval Prediction System
**AIML Summer Internship 2026 — IIHMF, MNNIT Allahabad**

This notebook implements the complete ML lifecycle for predicting loan approval:
Problem Understanding → Data Collection → Preprocessing → EDA → Feature Engineering →
Model Building → Model Evaluation.
""")

md("## Phase 1–2: Problem Understanding & Data Collection\n\nDataset attributes: `Loan_ID, Gender, Married, Dependents, Education, Self_Employed, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, Credit_History, Property_Area, Loan_Status`")

code("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
sns.set_style("whitegrid")

df = pd.read_csv("../Dataset/loan_data.csv")
df.head()""")

code("""print("Shape:", df.shape)
df.info()""")

code("""df.describe(include='all')""")

md("## Phase 3: Data Preprocessing")

code("""# Missing values
df.isnull().sum()""")

code("""df.drop(columns=["Loan_ID"], inplace=True)

# Fill categorical with mode
for col in ["Gender", "Married", "Dependents", "Self_Employed", "Credit_History", "Loan_Amount_Term"]:
    df[col] = df[col].fillna(df[col].mode()[0])

# Fill numeric with median
df["LoanAmount"] = df["LoanAmount"].fillna(df["LoanAmount"].median())

# Encode Dependents '3+' -> 3
df["Dependents"] = df["Dependents"].replace("3+", 3).astype(int)

print("Remaining missing values:\\n", df.isnull().sum().sum())""")

code("""# Duplicate check
print("Duplicate rows:", df.duplicated().sum())""")

code("""# Outlier check via boxplots
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
sns.boxplot(y=df["ApplicantIncome"], ax=axes[0]); axes[0].set_title("ApplicantIncome")
sns.boxplot(y=df["CoapplicantIncome"], ax=axes[1]); axes[1].set_title("CoapplicantIncome")
sns.boxplot(y=df["LoanAmount"], ax=axes[2]); axes[2].set_title("LoanAmount")
plt.tight_layout(); plt.show()""")

code("""# Cap extreme outliers using IQR capping (treat, not remove, to preserve sample size)
def cap_outliers(series):
    q1, q3 = series.quantile([0.25, 0.75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
    return series.clip(lower, upper)

for col in ["ApplicantIncome", "CoapplicantIncome", "LoanAmount"]:
    df[col] = cap_outliers(df[col])""")

md("## Phase 4: Exploratory Data Analysis (EDA)")

code("""# Univariate Analysis
fig, axes = plt.subplots(2, 2, figsize=(12, 8))
sns.histplot(df["ApplicantIncome"], kde=True, ax=axes[0,0]).set_title("Applicant Income Distribution")
sns.histplot(df["LoanAmount"], kde=True, ax=axes[0,1]).set_title("Loan Amount Distribution")
sns.countplot(x="Loan_Status", data=df, ax=axes[1,0]).set_title("Loan Status Count")
sns.countplot(x="Credit_History", data=df, ax=axes[1,1]).set_title("Credit History Count")
plt.tight_layout(); plt.show()""")

code("""# Bivariate Analysis
fig, axes = plt.subplots(1, 3, figsize=(16, 4))
sns.countplot(x="Credit_History", hue="Loan_Status", data=df, ax=axes[0]).set_title("Credit History vs Loan Status")
sns.boxplot(x="Loan_Status", y="ApplicantIncome", data=df, ax=axes[1]).set_title("Income vs Loan Status")
sns.countplot(x="Property_Area", hue="Loan_Status", data=df, ax=axes[2]).set_title("Property Area vs Loan Status")
plt.tight_layout(); plt.show()""")

code("""# Scatter plot: Income vs Loan Amount colored by approval
plt.figure(figsize=(7,5))
sns.scatterplot(x="ApplicantIncome", y="LoanAmount", hue="Loan_Status", data=df, alpha=0.7)
plt.title("Applicant Income vs Loan Amount")
plt.show()""")

code("""# Correlation heatmap (numeric columns only)
plt.figure(figsize=(8,6))
numeric_df = df.copy()
numeric_df["Loan_Status_num"] = numeric_df["Loan_Status"].map({"Y":1, "N":0})
corr = numeric_df.select_dtypes(include=np.number).corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()""")

md("## Phase 5: Feature Engineering")

code("""df["TotalIncome"] = df["ApplicantIncome"] + df["CoapplicantIncome"]
df["LoanAmount_log"] = np.log1p(df["LoanAmount"])
df["TotalIncome_log"] = np.log1p(df["TotalIncome"])
df["EMI"] = df["LoanAmount"] / df["Loan_Amount_Term"]
df["Balance_Income"] = df["TotalIncome"] - (df["EMI"] * 1000)

df[["TotalIncome", "EMI", "Balance_Income"]].describe()""")

code("""from sklearn.preprocessing import LabelEncoder

cat_cols = ["Gender", "Married", "Education", "Self_Employed", "Property_Area"]
encoders = {}
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    encoders[col] = le

target_le = LabelEncoder()
df["Loan_Status"] = target_le.fit_transform(df["Loan_Status"])  # N=0, Y=1
print(dict(zip(target_le.classes_, target_le.transform(target_le.classes_))))""")

code("""# Drop raw income/loan columns now that engineered log/total features exist (reduces multicollinearity)
features = [c for c in df.columns if c not in
            ["Loan_Status", "ApplicantIncome", "CoapplicantIncome", "LoanAmount", "TotalIncome"]]
X = df[features]
y = df["Loan_Status"]
print("Selected features:", features)""")

md("## Phase 6: Model Building")

code("""from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# Handle class imbalance with SMOTE (oversampling minority class on training data only)
sm = SMOTE(random_state=42)
X_train_bal, y_train_bal = sm.fit_resample(X_train_s, y_train)
print("Before SMOTE:", np.bincount(y_train))
print("After SMOTE :", np.bincount(y_train_bal))""")

code("""from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42),
    "XGBoost": XGBClassifier(n_estimators=200, max_depth=4, learning_rate=0.05,
                              use_label_encoder=False, eval_metric="logloss", random_state=42),
}

trained_models = {}
for name, model in models.items():
    model.fit(X_train_bal, y_train_bal)
    trained_models[name] = model
print("Trained:", list(trained_models.keys()))""")

md("## Phase 7: Model Evaluation")

code("""from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, confusion_matrix, classification_report,
                              roc_curve)

results = {}
for name, model in trained_models.items():
    pred = model.predict(X_test_s)
    proba = model.predict_proba(X_test_s)[:, 1]
    results[name] = {
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred),
        "Recall": recall_score(y_test, pred),
        "F1 Score": f1_score(y_test, pred),
        "ROC-AUC": roc_auc_score(y_test, proba),
    }

results_df = pd.DataFrame(results).T.round(4)
results_df""")

code("""results_df.plot(kind="bar", figsize=(10,5), ylim=(0,1))
plt.title("Model Comparison")
plt.ylabel("Score")
plt.xticks(rotation=0)
plt.legend(loc="lower right")
plt.tight_layout(); plt.show()""")

code("""# ROC Curves
plt.figure(figsize=(7,6))
for name, model in trained_models.items():
    proba = model.predict_proba(X_test_s)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, proba)
    plt.plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(y_test, proba):.3f})")
plt.plot([0,1],[0,1],"k--")
plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
plt.title("ROC Curves"); plt.legend(); plt.show()""")

code("""# Confusion matrix for the best model (by F1 score)
best_model_name = results_df["F1 Score"].idxmax()
best_model = trained_models[best_model_name]
pred = best_model.predict(X_test_s)

cm = confusion_matrix(y_test, pred)
plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Rejected","Approved"], yticklabels=["Rejected","Approved"])
plt.title(f"Confusion Matrix — {best_model_name}")
plt.ylabel("Actual"); plt.xlabel("Predicted")
plt.show()

print(f"Best Model: {best_model_name}\\n")
print(classification_report(y_test, pred, target_names=["Rejected","Approved"]))""")

code("""# Feature importance (tree-based best model) or coefficients (logistic regression)
if hasattr(best_model, "feature_importances_"):
    importances = pd.Series(best_model.feature_importances_, index=features).sort_values(ascending=False)
else:
    importances = pd.Series(np.abs(best_model.coef_[0]), index=features).sort_values(ascending=False)

plt.figure(figsize=(8,5))
sns.barplot(x=importances.values, y=importances.index)
plt.title(f"Feature Importance — {best_model_name}")
plt.tight_layout(); plt.show()""")

md("## Save Final Model Artifacts\n\nThe best-performing model, scaler, and encoders are saved for deployment in the Streamlit app.")

code("""import pickle, json, os

os.makedirs("../Model", exist_ok=True)

with open("../Model/best_model.pkl", "wb") as f:
    pickle.dump(best_model, f)
with open("../Model/scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)
with open("../Model/encoders.pkl", "wb") as f:
    pickle.dump(encoders, f)
with open("../Model/target_encoder.pkl", "wb") as f:
    pickle.dump(target_le, f)
with open("../Model/feature_list.json", "w") as f:
    json.dump(features, f)
with open("../Model/results.json", "w") as f:
    json.dump({"results": results, "best_model": best_model_name}, f, indent=2)

print("Saved all model artifacts to ../Model/")
print("Best model:", best_model_name)""")

md("""## Conclusion

- All three models (Logistic Regression, Random Forest, XGBoost) were trained on a
  preprocessed and SMOTE-balanced dataset.
- **Credit History**, **Total Income**, and **Loan Amount** emerged as the most
  influential predictors of loan approval.
- The best model (selected by F1 score) is saved and used in the Streamlit deployment app
  (`Streamlit_App/app.py`) for real-time predictions.

### Future Scope
- Hyperparameter tuning via GridSearchCV / Optuna
- Incorporate additional applicant data (CIBIL score history, existing liabilities)
- Try ensemble/stacking of multiple models
- Deploy on cloud (Streamlit Community Cloud / AWS / Render) with CI/CD
""")

nb["cells"] = cells
nbf.write(nb, "/home/claude/LoanApprovalPrediction/Notebook/Loan_Approval_Prediction.ipynb")
print("Notebook written.")
