import streamlit as st
import pandas as pd
import numpy as np
import pickle, json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "..", "Model")

st.set_page_config(page_title="Loan Approval Prediction", page_icon="💰", layout="centered")


@st.cache_resource
def load_artifacts():
    with open(os.path.join(MODEL_DIR, "best_model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "scaler.pkl"), "rb") as f:
        scaler = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "encoders.pkl"), "rb") as f:
        encoders = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "target_encoder.pkl"), "rb") as f:
        target_encoder = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "feature_list.json"), "r") as f:
        features = json.load(f)
    with open(os.path.join(MODEL_DIR, "results.json"), "r") as f:
        results = json.load(f)
    return model, scaler, encoders, target_encoder, features, results


model, scaler, encoders, target_encoder, features, results = load_artifacts()

st.title("💰 Loan Approval Prediction System")
st.caption("AIML Summer Internship 2026 — IIHMF, MNNIT Allahabad, Prayagraj")
st.write(
    f"**Model in use:** `{results['best_model']}` "
    f"(F1: {results['results'][results['best_model']]['F1']:.3f}, "
    f"ROC-AUC: {results['results'][results['best_model']]['ROC_AUC']:.3f})"
)

st.divider()
st.subheader("Applicant Details")

col1, col2 = st.columns(2)
with col1:
    gender = st.selectbox("Gender", ["Male", "Female"])
    married = st.selectbox("Married", ["Yes", "No"])
    dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
    education = st.selectbox("Education", ["Graduate", "Not Graduate"])
    self_employed = st.selectbox("Self Employed", ["Yes", "No"])
    property_area = st.selectbox("Property Area", ["Urban", "Semiurban", "Rural"])

with col2:
    applicant_income = st.number_input("Applicant Monthly Income (₹)", min_value=0, value=5000, step=500)
    coapplicant_income = st.number_input("Coapplicant Monthly Income (₹)", min_value=0, value=0, step=500)
    loan_amount = st.number_input("Loan Amount (in thousands ₹)", min_value=1, value=120, step=5)
    loan_amount_term = st.selectbox("Loan Amount Term (months)", [360, 300, 240, 180, 120, 84, 60, 36, 12])
    credit_history = st.selectbox("Credit History", ["Has credit history", "No credit history"])

credit_history_val = 1.0 if credit_history == "Has credit history" else 0.0
dependents_val = 3 if dependents == "3+" else int(dependents)

if st.button("Predict Loan Approval", type="primary", use_container_width=True):
    total_income = applicant_income + coapplicant_income
    loan_amount_log = np.log1p(loan_amount)
    total_income_log = np.log1p(total_income)
    emi = loan_amount / loan_amount_term
    balance_income = total_income - (emi * 1000)

    raw = {
        "Gender": gender,
        "Married": married,
        "Dependents": dependents_val,
        "Education": education,
        "Self_Employed": self_employed,
        "Loan_Amount_Term": float(loan_amount_term),
        "Credit_History": credit_history_val,
        "Property_Area": property_area,
        "LoanAmount_log": loan_amount_log,
        "TotalIncome_log": total_income_log,
        "EMI": emi,
        "Balance_Income": balance_income,
    }

    for col in ["Gender", "Married", "Education", "Self_Employed", "Property_Area"]:
        raw[col] = encoders[col].transform([raw[col]])[0]

    input_df = pd.DataFrame([raw])[features]
    input_scaled = scaler.transform(input_df)

    pred = model.predict(input_scaled)[0]
    proba = model.predict_proba(input_scaled)[0][1]
    label = target_encoder.inverse_transform([pred])[0]

    st.divider()
    if label == "Y":
        st.success(f"✅ Loan Approved — Confidence: {proba*100:.1f}%")
    else:
        st.error(f"❌ Loan Not Approved — Confidence: {(1-proba)*100:.1f}%")

    st.progress(float(proba))
    st.caption(f"Model estimated probability of approval: {proba*100:.1f}%")

st.divider()
with st.expander("📊 Model Performance (Test Set)"):
    res_df = pd.DataFrame(results["results"]).T.round(4)
    st.dataframe(res_df, use_container_width=True)

st.caption("Built for the AIML Summer Internship Capstone Project — Loan Approval Prediction System")
